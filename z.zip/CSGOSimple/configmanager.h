#include <iostream>
#include <vector>
#include <Windows.h>
#include <winerror.h>
#include <ShlObj.h>
#include <string>
#include "valve_sdk\misc\Color.hpp"
#include "JSON.h"
#include "valve_sdk\csgostructs.hpp"
#include "options.hpp"
#include <unordered_map>
#include <array>
#include <algorithm>
#include <fstream>

namespace Configs
{
	void DumpClassIDs(const char* fileName);

	void SaveCFG(std::string fileName);
	void LoadCFG(std::string fileName);
}
