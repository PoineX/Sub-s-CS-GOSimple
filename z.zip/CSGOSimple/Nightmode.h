#pragma once
#include "SpoofedConvar.hpp"

namespace nightmode
{
	void doNightmode();
}