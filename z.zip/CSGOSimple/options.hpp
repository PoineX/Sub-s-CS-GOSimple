#pragma once

#include <string>
#include <map>
#include "valve_sdk/Misc/Color.hpp"
#include "valve_sdk/kit_parser.hpp"
#include "valve_sdk/item_definitions.hpp"
#include <limits>

#define OPTION(type, var, val) type var = val

extern bool sendPacket;
extern bool aaSide;
extern QAngle ChamFakeAngle;
extern int Shots;

enum ChamsType_t
{
	CHAM_TYPE_MATERIAL,
	CHAM_TYPE_FLAT,
	CHAM_TYPE_VAPOR,
	CHAM_TYPE_GLOW
};

enum triggerbot_spots
{
	tbHead,
	tbChest,
	tbStomach,
	tbAll,
};

static char* TriggerSpots[] =
{
	"Head",
	"Chest",
	"Stomach",
	"All",
};

enum hitsounds
{
	NOHITSOUND,
	Aimware,
	skeethitmarker,
	the_hell
};

static char* HitSounds[] =
{
	"None",
	"Aimware",
	"skeethitmarker",
	"the hell"
};

enum Sky_t
{
	NO_SKYCHANGE,
	VIETNAM,
	VERTIGO,
	SKY_CSGO_NIGHT02,
	SKY_CSGO_NIGHT02B
};

enum Clantag_t
{
	DISABLED_CLANTAG,
	NO_CLANTAG,
	CSGOsimple_STATIC,
	CSGOsimple_ANIMATED,
	VALVE,
	gamesense
};


struct aimbot_settings {
	bool enabled = true;
	bool deathmatch = false;
	bool autopistol = false;
	bool check_smoke = false;
	bool check_flash = false;
	bool autowall = false;
	bool silent = false;
	bool rcs = false;
	bool rcs_fov_enabled = false;
	bool rcs_smooth_enabled = false;
	bool humanize = false;
	struct {
		bool enabled = true;
		int ticks = 10;
	} backtrack;
	bool only_in_zoom = true;
	int aim_type = 1;
	int priority = 0;
	int fov_type = 0;
	int rcs_type = 0;
	int hitbox = 1;
	float fov = 2.f;
	float silent_fov = 0.f;
	float rcs_fov = 0.f;
	float smooth = 13;
	float rcs_smooth = 1;
	int shot_delay = 0;
	int kill_delay = 0;
	int rcs_x = 100;
	int rcs_y = 100;
	int rcs_start = 1;
	int min_damage = 1;
};

static char* keyNames[] =
{
	"",
	"Mouse 1",
	"Mouse 2",
	"Cancel",
	"Middle Mouse",
	"Mouse 4",
	"Mouse 5",
	"",
	"Backspace",
	"Tab",
	"",
	"",
	"Clear",
	"Enter",
	"",
	"",
	"Shift",
	"Control",
	"Alt",
	"Pause",
	"Caps",
	"",
	"",
	"",
	"",
	"",
	"",
	"Escape",
	"",
	"",
	"",
	"",
	"Space",
	"Page Up",
	"Page Down",
	"End",
	"Home",
	"Left",
	"Up",
	"Right",
	"Down",
	"",
	"",
	"",
	"Print",
	"Insert",
	"Delete",
	"",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"",
	"",
	"",
	"",
	"",
	"Numpad 0",
	"Numpad 1",
	"Numpad 2",
	"Numpad 3",
	"Numpad 4",
	"Numpad 5",
	"Numpad 6",
	"Numpad 7",
	"Numpad 8",
	"Numpad 9",
	"Multiply",
	"Add",
	"",
	"Subtract",
	"Decimal",
	"Divide",
	"F1",
	"F2",
	"F3",
	"F4",
	"F5",
	"F6",
	"F7",
	"F8",
	"F9",
	"F10",
	"F11",
	"F12"
};


struct item_setting
{
	char name[32] = "Default";
	bool enabled = true;
	int definition_vector_index = 0;
	int definition_index = 1;
	int paint_kit_vector_index = 0;
	int paint_kit_index = 0;
	int definition_override_vector_index = 0;
	int definition_override_index = 0;
	int seed = 0;
	int stat_trak = 0;
	float wear = 0.000000001;
	char custom_name[32] = "";
};

class Config
{
public:
	OPTION(int, selected_config_index, 0);

	// 
	// ESP
	// 
	OPTION(bool, esp_enabled, true);
	OPTION(bool, esp_enemies_only, true);
	OPTION(bool, esp_player_boxes, false);
	OPTION(bool, esp_player_names, true);
	OPTION(bool, esp_player_health, true);
	OPTION(bool, esp_player_armour, false);
	OPTION(bool, esp_player_weapons, false);
	OPTION(bool, esp_player_snaplines, false);
	OPTION(bool, esp_crosshair, false);
	OPTION(bool, esp_dropped_weapons, false);
	OPTION(bool, esp_defuse_kit, false);
	OPTION(bool, esp_planted_c4, false);
	OPTION(bool, skeleton_shit, false);
	OPTION(bool, backtracking_tracer, false);  // fucked
	OPTION(int, esp_player_healthtype, 0);
	OPTION(bool, chams_player_xqz, false);
	OPTION(bool, esp_dmgindicator, false);  // fucked

	// 
	// GLOW
	// 
	OPTION(bool, glow_enabled, true);
	OPTION(bool, glow_enemies_only, true);
	OPTION(bool, glow_players, true);
	OPTION(bool, glow_chickens, false);
	OPTION(bool, glow_c4_carrier, false);
	OPTION(bool, glow_planted_c4, false);
	OPTION(bool, glow_defuse_kits, false);
	OPTION(bool, glow_weapons, false);

	//
	// Tibberbot 
	//
	OPTION(bool, triggerbotactive, false);
	OPTION(int, triggerbotkey, 0);
	OPTION(int, triggerbot_spot, 0);

	//
	// CHAMS
	//
	OPTION(bool, chams_player_enabled, false);
	OPTION(bool, chams_player_enemies_only, false);
	OPTION(bool, chams_player_wireframe, false);
	OPTION(bool, chams_player_flat, false);
	OPTION(bool, chams_player_ignorez, false);
	OPTION(bool, chams_player_glass, false);
	OPTION(bool, chams_arms_enabled, false);
	OPTION(bool, chams_arms_wireframe, false);
	OPTION(bool, chams_arms_flat, false);
	OPTION(bool, chams_arms_ignorez, false);
	OPTION(bool, chams_arms_glass, false);
	OPTION(bool, chams_localplayer, false);
	OPTION(int, chams_player_mode, CHAM_TYPE_MATERIAL);
	OPTION(bool, chams_arms_xqz, false);
	OPTION(bool, chams_translucent, false);
	OPTION(int, chams_arms_mode, CHAM_TYPE_MATERIAL);



	//
	// MISC
	//
	OPTION(bool, misc_bhop, true);
	OPTION(bool, misc_no_hands, false);
	OPTION(bool, misc_thirdperson, false);
	OPTION(float, misc_thirdperson_dist, 50.f);
	OPTION(int, viewmodel_fov, 67);
	OPTION(float, mat_ambient_light_r, 0.0f);
	OPTION(float, mat_ambient_light_g, 0.0f);
	OPTION(float, mat_ambient_light_b, 0.0f);
	OPTION(bool, watermarks, true);
	OPTION(bool, antiuntrusted, true);
	OPTION(bool, legit_antiaim, false);
	OPTION(float, legitaa_yaw, 89.0f);
	OPTION(bool, memewalk, false);
	OPTION(bool, misc_testaa, false);
	OPTION(bool, rank_reveal, false);
	OPTION(bool, nightmode, false);
	OPTION(int, sky, 0);
	OPTION(int, thirdperson_key, 0);
	OPTION(bool, hitmarkers, false);
	OPTION(int, hitmarkers_sound, false);
	OPTION(int, clantag, DISABLED_CLANTAG);

	// 
	// COLORS
	// 
	OPTION(Color, color_esp_ally_visible, Color(255, 255, 255));
	OPTION(Color, color_esp_enemy_visible, Color(255, 255, 255));
	OPTION(Color, color_esp_ally_occluded, Color(255, 255, 255));
	OPTION(Color, color_esp_enemy_occluded, Color(255, 255, 255));
	OPTION(Color, color_esp_crosshair, Color(255, 255, 255));
	OPTION(Color, color_esp_weapons, Color(255, 255, 255));
	OPTION(Color, color_esp_defuse, Color(0, 128, 255));
	OPTION(Color, color_esp_c4, Color(255, 255, 0));

	OPTION(Color, color_glow_ally, Color(0, 255, 255));
	OPTION(Color, color_glow_enemy, Color(0, 255, 255));
	OPTION(Color, color_glow_chickens, Color(0, 255, 255));
	OPTION(Color, color_glow_c4_carrier, Color(255, 255, 0));
	OPTION(Color, color_glow_planted_c4, Color(128, 0, 128));
	OPTION(Color, color_glow_defuse, Color(255, 255, 255));
	OPTION(Color, color_glow_weapons, Color(0, 255, 0, 255));

	OPTION(Color, color_chams_player_ally_visible, Color(0, 128, 255));
	OPTION(Color, color_chams_player_ally_occluded, Color(0, 255, 128));
	OPTION(Color, color_chams_player_enemy_visible, Color(255, 0, 0));
	OPTION(Color, color_chams_player_enemy_occluded, Color(255, 128, 0));
	OPTION(Color, color_chams_arms_visible, Color(0, 128, 255));
	OPTION(Color, color_chams_arms_occluded, Color(0, 128, 255));

	OPTION(int, pistol_backtracking_ticks, 12);
	OPTION(int, rifle_backtracking_ticks, 12);
	OPTION(int, sniper_backtracking_ticks, 12);
	OPTION(int, shotgun_backtracking_ticks, 12);
	OPTION(int, smg_backtracking_ticks, 12);
	OPTION(bool, rifle_backtracking, false);
	OPTION(bool, pistol_backtracking, false);
	OPTION(bool, sniper_backtracking, false);


	std::map<int, aimbot_settings> aimbot = {};

	bool enabled = true;
	bool deathmatch = false;
	bool autopistol = false;
	bool check_smoke = false;
	bool check_flash = false;
	bool autowall = false;
	bool silent = false;
	bool rcs = false;
	bool rcs_fov_enabled = false;
	bool rcs_smooth_enabled = false;
	bool humanize = false;
	struct {
		bool enabled = true;
		int ticks = 10;
	} backtrack;
	bool only_in_zoom = true;
	int aim_type = 1;
	int priority = 0;
	int fov_type = 0;
	int rcs_type = 0;
	int hitbox = 1;
	float fov = 2.f;
	float silent_fov = 0.f;
	float rcs_fov = 0.f;
	float smooth = 13;
	float rcs_smooth = 1;
	int shot_delay = 0;
	int kill_delay = 0;
	int rcs_x = 100;
	int rcs_y = 100;
	int rcs_start = 1;
	int min_damage = 1;


	struct {
		std::map<int, item_setting> m_items;
		std::unordered_map<std::string, std::string> m_icon_overrides;
		auto get_icon_override(const std::string original) const -> const char*
		{
			return m_icon_overrides.count(original) ? m_icon_overrides.at(original).data() : nullptr;
		}
	} skins;
};

extern Config g_Options;
extern bool   g_Unload;
extern bool   g_Save;
extern bool   g_Load;
extern bool   g_Clear;
extern bool   g_View;