#pragma once
#include "valve_sdk\csgostructs.hpp"


namespace triggerbot
{
	void Triggerbot(CUserCmd* pCmd);
}
