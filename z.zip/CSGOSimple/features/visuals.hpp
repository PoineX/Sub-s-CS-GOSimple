#pragma once

class C_BasePlayer;
class C_BaseEntity;
class C_BaseCombatWeapon;
class C_PlantedC4;
class Color;
class ClientClass;
class CUserCmd;

namespace Visuals
{
	struct ESPBox
	{
		int x, y, w, h, gay;
	};

    namespace Player
    {
        bool Begin(C_BasePlayer* pl);

        void RenderBox();
        void RenderName();
        void RenderHealth();
		void RenderArmour();	
        void RenderWeapon();
        void RenderSnapline();
		void RenderHealth2(C_BasePlayer* pEntity);
		extern bool esp_HealthChams;

    }

    namespace Misc
    {
        void RenderCrosshair();
        void RenderWeapon(C_BaseCombatWeapon* ent);
        void RenderDefuseKit(C_BaseEntity* ent);
        void RenderPlantedC4(C_BaseEntity* ent);
		void ThirdPerson();
		void DrawSkeleton(C_BasePlayer* pEntity);
    }

    bool CreateFonts();
    void DestroyFonts();
}
