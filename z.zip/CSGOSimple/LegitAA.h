#pragma once
#include "valve_sdk\csgostructs.hpp"


namespace LegitAntiAim
{
	void LegitAA(CUserCmd *pCmd, bool& bSendPacket);
}

class CUserCmd;

namespace memewalk
{
	void OnCreateMove(CUserCmd* cmd);
}