#pragma once
#include "JSON.h"
#include "valve_sdk\csgostructs.hpp"
#include "options.hpp"
#include "configmanager.h"
#include <unordered_map>
#include <array>
#include <algorithm>
#include <fstream>

class pstring : public std::string
{
public:
	pstring() : std::string() {}

	template<typename T>
	pstring(const T v) : std::string(v) {}

	template<typename T>
	pstring& operator<<(const T s)
	{
		std::stringstream stream;
		stream << *this;
		stream << s;
		*this = stream.str();
		return *this;
	}

	pstring& operator+(const unsigned int i)
	{
		std::stringstream stream;
		stream << *this;
		stream << i;
		*this = stream.str();
		return *this;
	}
};

namespace Configs
{
	void DumpClassIDs(const char* fileName)
	{
		auto stream = std::ofstream(fileName);

		stream << "--------------------[ Sub's CLASS ID DUMP ]--------------------" << std::endl;
		stream << std::endl;
		stream << "enum ClassId" << std::endl;
		stream << "{" << std::endl;

		for (ClientClass* DumpClass = g_CHLClient->GetAllClasses(); DumpClass; DumpClass = DumpClass->m_pNext)
			stream << "\tClassId_" << DumpClass->m_pNetworkName << " = " << DumpClass->m_ClassID << "," << std::endl;

		stream << "}" << std::endl;
	}

	void GetVal(Json::Value &config, int* setting)
	{
		if (config.isNull())
			return;

		*setting = config.asInt();
	}

	void GetVal(Json::Value &config, bool* setting)
	{
		if (config.isNull())
			return;

		*setting = config.asBool();
	}

	void GetVal(Json::Value &config, float* setting)
	{
		if (config.isNull())
			return;

		*setting = config.asFloat();
	}

	void GetVal(Json::Value &config, Color* setting)
	{
		if (config.isNull())
			return;

		static int R, G, B, A;

		GetVal(config["R"], &R);
		GetVal(config["G"], &G);
		GetVal(config["B"], &B);
		GetVal(config["A"], &A);

		setting->SetColor(R, G, B, A);
	}

	void GetVal(Json::Value &config, char** setting)
	{
		if (config.isNull())
			return;

		*setting = strdup(config.asCString());
	}

	void GetVal(Json::Value &config, char* setting)
	{
		if (config.isNull())
			return;

		strcpy(setting, config.asCString());
	}

	void LoadColor(Json::Value &config, Color* color)
	{
		static int R, G, B, A;

		color->GetColor(R, G, B, A);

		config["R"] = R;
		config["G"] = G;
		config["B"] = B;
		config["A"] = A;
	}

	void SaveCFG(std::string fileName)
	{
		Json::Value settings;

		//
		//Aim
		//

		GetVal(settings["Aimbot"]["Autowall"], &g_Options.autowall);



		//
		// VISUALS
		//
		GetVal(settings["Visuals"]["Player ESP"], &g_Options.esp_enabled);
		GetVal(settings["Visuals"]["Enemies Only ESP"], &g_Options.esp_enemies_only);
		GetVal(settings["Visuals"]["Player Boxes"], &g_Options.esp_player_boxes);
		GetVal(settings["Visuals"]["Player Names"], &g_Options.esp_player_names);
		GetVal(settings["Visuals"]["Player Health"], &g_Options.esp_player_health);
		GetVal(settings["Visuals"]["Player Armor"], &g_Options.esp_player_armour);
		GetVal(settings["Visuals"]["Player Weapons"], &g_Options.esp_player_weapons);
		GetVal(settings["Visuals"]["Player Snaplines"], &g_Options.esp_player_snaplines);
		GetVal(settings["Visuals"]["Crosshair"], &g_Options.esp_crosshair);
		GetVal(settings["Visuals"]["Dropped Weapons ESP"], &g_Options.esp_dropped_weapons);
		GetVal(settings["Visuals"]["Defuse Kit ESP"], &g_Options.esp_defuse_kit);
		GetVal(settings["Visuals"]["Planted C4 ESP"], &g_Options.esp_planted_c4);
		GetVal(settings["Visuals"]["Glow"], &g_Options.glow_enabled);
		GetVal(settings["Visuals"]["Enemies Only Glow"], &g_Options.glow_enemies_only);
		GetVal(settings["Visuals"]["Glow Players"], &g_Options.glow_players);
		GetVal(settings["Visuals"]["Glow Chickens"], &g_Options.glow_chickens);
		GetVal(settings["Visuals"]["Glow C4 Carrier"], &g_Options.glow_c4_carrier);
		GetVal(settings["Visuals"]["Glow Planted C4"], &g_Options.glow_planted_c4);
		GetVal(settings["Visuals"]["Glow Defuse Kits"], &g_Options.glow_defuse_kits);
		GetVal(settings["Visuals"]["Glow Weapons"], &g_Options.glow_weapons);
		GetVal(settings["Visuals"]["Chams Players"], &g_Options.chams_player_enabled);
		GetVal(settings["Visuals"]["Chams Enemies Only"], &g_Options.chams_player_enemies_only);
		GetVal(settings["Visuals"]["Chams Player Wireframe"], &g_Options.chams_player_wireframe);
		GetVal(settings["Visuals"]["Chams Arms"], &g_Options.chams_arms_enabled);
		GetVal(settings["Visuals"]["Chams Arms Wireframe"], &g_Options.chams_arms_wireframe);
		GetVal(settings["Visuals"]["No Hands"], &g_Options.misc_no_hands);
		GetVal(settings["Visuals"]["Viewmodel FOV"], &g_Options.viewmodel_fov);
		GetVal(settings["Visuals"]["Camera FOV"], &g_Options.fov);
		GetVal(settings["Visuals"]["Ambient Light R"], &g_Options.mat_ambient_light_r);
		GetVal(settings["Visuals"]["Ambient Light G"], &g_Options.mat_ambient_light_g);
		GetVal(settings["Visuals"]["Ambient Light B"], &g_Options.mat_ambient_light_b);
		GetVal(settings["Visuals"]["Watermarks"], &g_Options.watermarks);
		//
		// MISC
		//
		GetVal(settings["Misc"]["Third Person"], &g_Options.misc_thirdperson);
		GetVal(settings["Misc"]["Bunnyhop Key"], &g_Options.misc_bhop);
		GetVal(settings["Misc"]["Moonwalk"], &g_Options.memewalk);
		GetVal(settings["Misc"]["Anti-Untrusted"], &g_Options.antiuntrusted);
		GetVal(settings["Misc"]["Legit Antiaim"], &g_Options.legit_antiaim);
		GetVal(settings["Misc"]["Legit AA"], &g_Options.legit_antiaim);
		GetVal(settings["Misc"]["Legit AA Yaw"], &g_Options.legitaa_yaw);


		GetVal(settings["Triggerbot"]["Active"], &g_Options.triggerbotactive);
		GetVal(settings["Triggerbot"]["Trigger key"], &g_Options.triggerbotkey);
		GetVal(settings["Triggerbot"]["Trigger Spot"], &g_Options.triggerbot_spot);

		//
		//Colors
		//
		GetVal(settings["Colors"]["Ally Visible Color"], &g_Options.color_esp_ally_visible);
		GetVal(settings["Colors"]["Ally Occluded Color"], &g_Options.color_esp_ally_occluded);
		GetVal(settings["Colors"]["Enemy Visible Color"], &g_Options.color_esp_enemy_visible);
		GetVal(settings["Colors"]["Enemy Occluded Color"], &g_Options.color_esp_enemy_occluded);
		GetVal(settings["Colors"]["Weapon ESP Color"], &g_Options.color_esp_weapons);
		GetVal(settings["Colors"]["Defuse Kit ESP Color"], &g_Options.color_esp_defuse);
		GetVal(settings["Colors"]["C4 ESP Color"], &g_Options.color_esp_c4);
		GetVal(settings["Colors"]["Ally Glow Color"], &g_Options.color_glow_ally);
		GetVal(settings["Colors"]["Enemy Glow Color"], &g_Options.color_glow_enemy);
		GetVal(settings["Colors"]["Chicken Glow Color"], &g_Options.color_glow_chickens);
		GetVal(settings["Colors"]["C4 Carrier Glow Color"], &g_Options.color_glow_c4_carrier);
		GetVal(settings["Colors"]["Planted C4 Glow Color"], &g_Options.color_glow_planted_c4);
		GetVal(settings["Colors"]["Defuse Kit Glow Color"], &g_Options.color_glow_defuse);
		GetVal(settings["Colors"]["Weapons Glow Color"], &g_Options.color_glow_weapons);
		GetVal(settings["Colors"]["Ally Chams Visible Color"], &g_Options.color_chams_player_ally_visible);
		GetVal(settings["Colors"]["Ally Chams Occluded Color"], &g_Options.color_chams_player_ally_occluded);
		GetVal(settings["Colors"]["Enemy Chams Visible Color"], &g_Options.color_chams_player_enemy_visible);
		GetVal(settings["Colors"]["Enemy Chams Occluded Color"], &g_Options.color_chams_player_enemy_occluded);
		GetVal(settings["Colors"]["Arm Chams Visible Color"], &g_Options.color_chams_arms_visible);
		GetVal(settings["Colors"]["Arm Chams Occluded Color"], &g_Options.color_chams_arms_occluded);

		Json::StyledWriter styledWriter;
		std::string strJson = styledWriter.write(settings);
		FILE* file = fopen(fileName.c_str(), "w+");
		if (file)
		{
			fwrite(strJson.c_str(), 1, strJson.length(), file);
			fclose(file);
		}
	}

	void LoadCFG(std::string fileName)
	{
		FILE* infile = fopen(fileName.c_str(), "r");

		if (!infile)
		{
			SaveCFG(fileName);
			return;
		}

		fseek(infile, 0, SEEK_END);
		long filesize = ftell(infile);
		char* buf = new char[filesize + 1];
		fseek(infile, 0, SEEK_SET);
		fread(buf, 1, filesize, infile);
		fclose(infile);

		buf[filesize] = '\0';
		std::stringstream ss;
		ss.str(buf);
		delete[] buf;

		Json::Value settings;
		ss >> settings;
		//
		//Aim
		//

		GetVal(settings["Aimbot"]["Autowall"], &g_Options.autowall);



		//
		// VISUALS
		//
		GetVal(settings["Visuals"]["Player ESP"], &g_Options.esp_enabled);
		GetVal(settings["Visuals"]["Enemies Only ESP"], &g_Options.esp_enemies_only);
		GetVal(settings["Visuals"]["Player Boxes"], &g_Options.esp_player_boxes);
		GetVal(settings["Visuals"]["Player Names"], &g_Options.esp_player_names);
		GetVal(settings["Visuals"]["Player Health"], &g_Options.esp_player_health);
		GetVal(settings["Visuals"]["Player Armor"], &g_Options.esp_player_armour);
		GetVal(settings["Visuals"]["Player Weapons"], &g_Options.esp_player_weapons);
		GetVal(settings["Visuals"]["Player Snaplines"], &g_Options.esp_player_snaplines);
		GetVal(settings["Visuals"]["Crosshair"], &g_Options.esp_crosshair);
		GetVal(settings["Visuals"]["Dropped Weapons ESP"], &g_Options.esp_dropped_weapons);
		GetVal(settings["Visuals"]["Defuse Kit ESP"], &g_Options.esp_defuse_kit);
		GetVal(settings["Visuals"]["Planted C4 ESP"], &g_Options.esp_planted_c4);
		GetVal(settings["Visuals"]["Glow"], &g_Options.glow_enabled);
		GetVal(settings["Visuals"]["Enemies Only Glow"], &g_Options.glow_enemies_only);
		GetVal(settings["Visuals"]["Glow Players"], &g_Options.glow_players);
		GetVal(settings["Visuals"]["Glow Chickens"], &g_Options.glow_chickens);
		GetVal(settings["Visuals"]["Glow C4 Carrier"], &g_Options.glow_c4_carrier);
		GetVal(settings["Visuals"]["Glow Planted C4"], &g_Options.glow_planted_c4);
		GetVal(settings["Visuals"]["Glow Defuse Kits"], &g_Options.glow_defuse_kits);
		GetVal(settings["Visuals"]["Glow Weapons"], &g_Options.glow_weapons);
		GetVal(settings["Visuals"]["Chams Players"], &g_Options.chams_player_enabled);
		GetVal(settings["Visuals"]["Chams Enemies Only"], &g_Options.chams_player_enemies_only);
		GetVal(settings["Visuals"]["Chams Player Wireframe"], &g_Options.chams_player_wireframe);
		GetVal(settings["Visuals"]["Chams Arms"], &g_Options.chams_arms_enabled);
		GetVal(settings["Visuals"]["Chams Arms Wireframe"], &g_Options.chams_arms_wireframe);
		GetVal(settings["Visuals"]["No Hands"], &g_Options.misc_no_hands);
		GetVal(settings["Visuals"]["Viewmodel FOV"], &g_Options.viewmodel_fov);
		GetVal(settings["Visuals"]["Camera FOV"], &g_Options.fov);
		GetVal(settings["Visuals"]["Ambient Light R"], &g_Options.mat_ambient_light_r);
		GetVal(settings["Visuals"]["Ambient Light G"], &g_Options.mat_ambient_light_g);
		GetVal(settings["Visuals"]["Ambient Light B"], &g_Options.mat_ambient_light_b);
		GetVal(settings["Visuals"]["Watermarks"], &g_Options.watermarks);
		//
		// MISC
		//
		GetVal(settings["Misc"]["Third Person"], &g_Options.misc_thirdperson);
		GetVal(settings["Misc"]["Bunnyhop Key"], &g_Options.misc_bhop);
		GetVal(settings["Misc"]["Moonwalk"], &g_Options.memewalk);
		GetVal(settings["Misc"]["Anti-Untrusted"], &g_Options.antiuntrusted);
		GetVal(settings["Misc"]["Legit Antiaim"], &g_Options.legit_antiaim);
		GetVal(settings["Misc"]["Legit AA"], &g_Options.legit_antiaim);
		GetVal(settings["Misc"]["Legit AA Yaw"], &g_Options.legitaa_yaw);

		GetVal(settings["Triggerbot"]["Active"], &g_Options.triggerbotactive);
		GetVal(settings["Triggerbot"]["Trigger key"], &g_Options.triggerbotkey);
		GetVal(settings["Triggerbot"]["Trigger Spot"], &g_Options.triggerbot_spot);

		//
		//Colors
		//
		GetVal(settings["Colors"]["Ally Visible Color"], &g_Options.color_esp_ally_visible);
		GetVal(settings["Colors"]["Ally Occluded Color"], &g_Options.color_esp_ally_occluded);
		GetVal(settings["Colors"]["Enemy Visible Color"], &g_Options.color_esp_enemy_visible);
		GetVal(settings["Colors"]["Enemy Occluded Color"], &g_Options.color_esp_enemy_occluded);
		GetVal(settings["Colors"]["Weapon ESP Color"], &g_Options.color_esp_weapons);
		GetVal(settings["Colors"]["Defuse Kit ESP Color"], &g_Options.color_esp_defuse);
		GetVal(settings["Colors"]["C4 ESP Color"], &g_Options.color_esp_c4);
		GetVal(settings["Colors"]["Ally Glow Color"], &g_Options.color_glow_ally);
		GetVal(settings["Colors"]["Enemy Glow Color"], &g_Options.color_glow_enemy);
		GetVal(settings["Colors"]["Chicken Glow Color"], &g_Options.color_glow_chickens);
		GetVal(settings["Colors"]["C4 Carrier Glow Color"], &g_Options.color_glow_c4_carrier);
		GetVal(settings["Colors"]["Planted C4 Glow Color"], &g_Options.color_glow_planted_c4);
		GetVal(settings["Colors"]["Defuse Kit Glow Color"], &g_Options.color_glow_defuse);
		GetVal(settings["Colors"]["Weapons Glow Color"], &g_Options.color_glow_weapons);
		GetVal(settings["Colors"]["Ally Chams Visible Color"], &g_Options.color_chams_player_ally_visible);
		GetVal(settings["Colors"]["Ally Chams Occluded Color"], &g_Options.color_chams_player_ally_occluded);
		GetVal(settings["Colors"]["Enemy Chams Visible Color"], &g_Options.color_chams_player_enemy_visible);
		GetVal(settings["Colors"]["Enemy Chams Occluded Color"], &g_Options.color_chams_player_enemy_occluded);
		GetVal(settings["Colors"]["Arm Chams Visible Color"], &g_Options.color_chams_arms_visible);
		GetVal(settings["Colors"]["Arm Chams Occluded Color"], &g_Options.color_chams_arms_occluded);


		// update skins
		g_ClientState->ForceFullUpdate();
	}
}