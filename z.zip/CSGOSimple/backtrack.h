#pragma once
#include "options.hpp"
#include "valve_sdk/csgostructs.hpp"
#include "helpers/math.hpp"
struct backtrack_data {
	int tick_count;
	int m_iTeamNum;
	Vector hitboxPos;
	int EntIndex;
	std::vector<backtrack_data> records;
	C_BasePlayer* entity;
	Vector head;
	Vector origin;
};
class Backtrack {
public:
	void OnMove(CUserCmd *pCmd);
	std::vector<backtrack_data> ticks;

	void Draw()
	{
		auto pWeapon = g_LocalPlayer->m_hActiveWeapon();

		if (pWeapon) {

			if (pWeapon->IsGrenade() || pWeapon->IsKnife() || pWeapon->m_iItemDefinitionIndex() == WEAPON_C4) return;

			if (pWeapon->IsPistol() && !g_Options.pistol_backtracking) return;
			else if (pWeapon->IsRifle() && !g_Options.rifle_backtracking) return;
			else if (pWeapon->IsSniper() && !g_Options.sniper_backtracking) return;


			for (auto& tick : ticks)
			{
				for (auto& record : tick.records)
				{
					Vector screenPos;
					if (Math::WorldToScreen(record.head, screenPos))
					{
						g_VGuiSurface->DrawSetColor(63, 255, 223, 255);
						g_VGuiSurface->DrawFilledRect(screenPos.x, screenPos.y, screenPos.x + 2, screenPos.y + 2);
					}
				}
			}
		}
	}

private:
	std::vector<backtrack_data> data = {};

};
extern Backtrack g_Backtrack;


