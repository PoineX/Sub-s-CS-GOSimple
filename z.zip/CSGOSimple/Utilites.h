#define NOMINMAX
#include <Windows.h>
#include <string>
#include <initializer_list>



namespace Utilities
{
	std::string GetTimeString();
	std::string GetFPS();
	std::string Truncate(std::string str, size_t width, bool show_ellipsis = true);

	template <typename T>
	std::wstring to_wstring(const T a_value, const int precision = 6)
	{
		std::wostringstream out;
		out << std::setprecision(precision) << a_value;
		return out.str();
	}

	void SetupConsole();
	void CloseConsole();
	bool ConsolePrint(const char* Message, bool NewLine = true);
	bool ConsolePrint(std::string Message, bool NewLine = true);
	DWORD GetModuleSize(char * ModuleName);
	std::uint8_t* PatternScan(void* Module, const char* Signature);
	int WaitForModules(std::int32_t Timeout, const std::initializer_list<std::wstring>& Modules);
	void SetClantag(const char* tag);
	void SetClantag(std::wstring tag);
	void SetName(const char* name);
	void RevealRanks();
	std::string WstringToString(std::wstring wstr);
	std::wstring StringToWstring(std::string str);
	bool IsCodePtr(void* ptr);
}
